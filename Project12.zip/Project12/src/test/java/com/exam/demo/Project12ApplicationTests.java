package com.exam.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Project12ApplicationTests {

	@Test
	void contextLoads() {
	}

}
