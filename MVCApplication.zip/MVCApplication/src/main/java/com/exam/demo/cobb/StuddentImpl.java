package com.exam.demo.cobb;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class StuddentImpl implements StudentModel
{
    @Autowired
	StudentRepo repo;

	@Override
	public Student addStudent(Student std) {
		
		return repo.save(std);
	}

	@Override
	public List<Student> getAllStudent() {
		
		return repo.findAll();
	}

	@Override
	public Student getById(Integer id) {
		       Optional<Student> findById = repo.findById(id);
		       if(findById.isPresent())
		       {
		    	  return findById.get();
		       }
		return null;
		
	}

	@Override
	public String deleteById(Integer id) {
		  
		repo.deleteById(id);
		return"deleted";
		
	}

	@Override
	public Student updateStudent(Integer id, Student std) {
		   Optional<Student> find = repo.findById(id);
		   if(find.isPresent())
		   {
			   Student s = find.get();
			   s.setName(std.getName());
			   s.setPhno(std.getPhno());
			   s.setBranch(std.getBranch());
			  return repo.save(s);
		   }
		return null;
	}

}
