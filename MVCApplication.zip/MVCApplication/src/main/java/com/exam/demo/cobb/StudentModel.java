package com.exam.demo.cobb;

import java.util.List;

public interface StudentModel 
{
  Student addStudent(Student std);
  
  List<Student> getAllStudent();
  
  Student getById(Integer id);
  
  String deleteById(Integer id);
  
  Student updateStudent(Integer id,Student std);
}
