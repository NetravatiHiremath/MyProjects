package com.exam.demo.cobb;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller1 
{
	@Autowired
	StudentModel model;
	@GetMapping("/vijet")
	public void getM() {
		System.out.println("vijet");
	}
	
   @PostMapping("/s")
   public Student save(@RequestBody Student std)
   {
	   System.out.println("hiii");
	   Student s = model.addStudent(std);
	   return s;
	     
   }
   
   @GetMapping("/g")
   public List<Student> get()
   {
	   List<Student> std=model.getAllStudent();
	return std;
   }
   
   @GetMapping("/gg/{id}")
   public Student getById(@PathVariable Integer id)
   {
	 return model.getById(id);
	   
   }
   
   @DeleteMapping("/d")
   public String delete(@PathVariable Integer id)
   {
	   model.deleteById(id);
	   return "Data Deleted";
	   
   }
   
   @PutMapping("/p/{id}")
   public Student update(@PathVariable Integer id ,@RequestBody Student s)
   {
	    return model.updateStudent(id, s);
   }
}
